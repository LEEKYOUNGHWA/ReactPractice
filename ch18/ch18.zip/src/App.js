import React from 'react';
import Color from './components/Color';

const App = () => {
  return (
    <div>
      <Color />
    </div>
  );
};

export default App;