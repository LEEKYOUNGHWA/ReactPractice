import React, { Component } from 'react';

class Color extends Component {
    render() {
        return (
            <div>
                <h1>컬러바꾸기 연습</h1>
                <button>green</button>
                <button>yellow</button>
                <button>blue</button>
                <button>pink</button>
                <button>skyblue</button>
            </div>
        );
    }
}

export default Color;